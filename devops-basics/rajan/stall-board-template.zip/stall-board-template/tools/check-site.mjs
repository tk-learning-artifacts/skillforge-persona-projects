// Checks the site before it can be merged or deployed. Run: node tools/check-site.mjs
// Needs only Node.js, which GitHub's Ubuntu runners already have.
import fs from 'node:fs';
import path from 'node:path';

const SKIP = new Set(['.git', '.github', 'tools', 'node_modules']);
const problems = [];
let checked = 0;

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (SKIP.has(e.name)) continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) walk(full, out);
    else out.push(full);
  }
  return out;
}

const files = walk('.').map((f) => path.relative('.', f).split(path.sep).join('/'));

for (const file of files) {
  const name = path.basename(file);
  if (name === '.env' || name.startsWith('.env.')) problems.push(`${file}: .env files hold keys. Delete it and keep it on your own computer.`);
}

for (const file of files.filter((f) => /\.(html|js|css|json)$/.test(f))) {
  const text = fs.readFileSync(file, 'utf8');
  checked++;
  // A key, password or token written into the code.
  const key = text.match(/(api[_-]?key|secret|password|passwd|token)["']?\s*[:=]/i);
  if (key) problems.push(`${file}: looks like a key or password ("${key[0]}"). Take it out. If it was real, cancel it.`);
  // An email address is personal data.
  const email = text.match(/[\w.+-]+@[\w-]+\.[\w.]{2,}/);
  if (email) problems.push(`${file}: has an email address. Take it out.`);

  if (!file.endsWith('.html')) continue;
  const title = text.match(/<title>([^<]*)<\/title>/i);
  if (!title || !title[1].trim()) problems.push(`${file}: no <title>.`);
  const h1s = (text.match(/<h1[\s>]/gi) || []).length;
  if (h1s !== 1) problems.push(`${file}: needs exactly 1 <h1>, found ${h1s}.`);
  if (file.startsWith('stalls/')) {
    if (!/class="menu"/.test(text)) problems.push(`${file}: no menu list (class="menu").`);
    else if (!/\$\d+\.\d\d/.test(text)) problems.push(`${file}: the menu has no prices like $2.50.`);
  }
  // Every link and file inside the site must exist.
  for (const m of text.matchAll(/(?:href|src)="([^"]+)"/g)) {
    const link = m[1];
    if (/^(https?:|mailto:|#)/.test(link)) continue;
    let target = path.posix.normalize(path.posix.join(path.posix.dirname(file), link.split(/[?#]/)[0]));
    if (link.endsWith('/')) target = path.posix.join(target, 'index.html');
    if (!files.includes(target)) problems.push(`${file}: link to "${link}" goes nowhere.`);
  }
}

console.log(`Checked ${checked} files.`);
if (problems.length) {
  for (const p of problems) console.log(`FAIL ${p}`);
  console.log(`${problems.length} problem(s). Fix them, commit, and the check runs again.`);
  process.exit(1);
}
console.log('All good. Ready to merge.');
