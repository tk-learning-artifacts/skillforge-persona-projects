## What this changes

Closes #

## Checklist

- [ ] I made this change on my own branch, not on main.
- [ ] I opened every page I changed in the preview.
- [ ] No real names, emails, photos or class numbers.
- [ ] No keys, passwords or tokens anywhere.
- [ ] I asked one teammate to review.
