---
name: Stall page
about: One stall, one page, one owner
title: "Add the ___ stall page"
labels: task
---

## The task

Make `stalls/<stall-name>.html` from `stalls/example.html`.
Add a link to it in the list on `index.html`.

## Done when

- [ ] The page has a title, one heading and a menu with prices.
- [ ] The link on the home page opens it.
- [ ] The check passes on your pull request.
