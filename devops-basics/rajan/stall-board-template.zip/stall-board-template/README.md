# Stall Board

A small website for your school canteen. Each person in your team builds one stall page.
Every change goes through a pull request. When a pull request is merged, the site updates itself.

## Set up (teacher, once per team)

1. Click **Use this template**, then **Create a new repository**. Make it public.
2. Settings > Pages > Source: **GitHub Actions**.
3. Settings > Rules > Rulesets > New branch ruleset. Target the default branch. Turn on:
   - Require a pull request before merging, with 1 required approval
   - Require status checks to pass, and add the check called `check`
   - Block force pushes and Restrict deletions (on by default)
4. Settings > Collaborators: add each student's account. Students must be 13 or older.
5. Open one issue per task below and assign one student to each.

## Your 3 tasks

1. **Your stall page.** Copy `stalls/example.html` to `stalls/<your-stall>.html`. Fill in the menu with at least 4 dishes and prices. Link it from `index.html`.
2. **Review a teammate.** Open their pull request. Open their page in the preview. Approve it or ask for one change.
3. **Fix a red check.** If the check fails on your pull request, read the first FAIL line, fix it, and commit again.

## How to make a change

1. Open the repository and press `.` to open github.dev.
2. Click the branch name `main` in the status bar at the bottom. Create a new branch, named like `add-chicken-rice`.
3. Make your change. In Source Control, write a short message and click **Commit & Push**.
4. Click the pull request icon at the top of the Source Control view. Fill in the checklist.
5. Wait for the check to go green and for one approval. Then click **Squash and merge**.

## Rules

- Never commit to `main`. The ruleset stops you anyway.
- One stall, one branch, one pull request.
- No real names, emails, photos or class numbers. Your account name should not be your real name.
- No keys or passwords in the code. The check looks for them.
- Merge your own pull request only after a teammate approves it.

## The check

`tools/check-site.mjs` runs on every pull request. It fails if a page has no title, a link goes nowhere,
a stall page has no prices, or a file has a key or an email address in it.
Run it yourself with `node tools/check-site.mjs` if you have Node.js.
