# Team site template

A small website your team builds together, one page each.
Every change goes through a pull request. When one is merged, the site updates itself.

## Set up (teacher, once per team)

1. Click **Use this template**, then **Create a new repository**. Make it public.
2. Settings > Pages > Source: **GitHub Actions**. The workflow is already here.
3. Settings > Rules > Rulesets > New branch ruleset, for the default branch:
   **Require a pull request before merging**, with 1 required approval.
4. Settings > Collaborators: add each member who is 13 or older.
5. Open one issue per page, using the **New page** issue template.

## Your 3 tasks

1. **Make your page.** Copy `starters/copy-me.html`, fill it in, and link it from `index.html`.
2. **Review a teammate's page.** Use the checklist in their pull request. Approve, or ask for one change.
3. **Fix the home page together.** Change the title and the first line of `index.html` to say what your site is for.

## How to make a change, all in the browser

1. Open the file on GitHub and click the pencil to edit it.
   To add a file, use **Add file** > **Create new file**.
2. Click **Commit changes**. Choose to create a new branch. Name it after your task.
3. Click **Propose changes**, then **Create pull request**. Fill in the checklist.
4. When a teammate approves, click **Squash and merge**, then **Delete branch**.
5. Open the **Actions** tab to watch the deploy. Then open your live site.

## Rules

See `how-we-work.html`. It is part of your site, so visitors can see how you work too.
