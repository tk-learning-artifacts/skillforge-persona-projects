## What I changed

Closes #

## Reviewer, please check

- [ ] The page opens from the home page link.
- [ ] Every link on the page works.
- [ ] No real names, emails, photos, class numbers or school details.
- [ ] No keys, passwords or tokens.
- [ ] Words a Sec 1 student would know. Sentences short enough to read aloud.
