---
name: New page
about: One page, one owner, one pull request
title: "Add the ___ page"
labels: task
---

## The page

Copy `starters/copy-me.html`. Rename it after your page, in lowercase with dashes.

## Done when

- [ ] The page has a title, a "you need" list and steps.
- [ ] The home page links to it.
- [ ] A teammate has approved the pull request.
