// The rules of Pig, with no SwiftUI in sight.
// Keeping the rules apart from the screens means I can test them on their own.

enum Player: Int {
    case one = 0, two = 1
    var other: Player { self == .one ? .two : .one }
}

// What just happened. The screen turns each event into words, a sound and a wiggle.
enum PigEvent: Equatable {
    case rolled(Int)
    case pigOut          // rolled a 1: turn points lost
    case held(Int)       // banked this many points
    case won(Player)
}

struct PigGame {
    let target: Int
    private(set) var scores = [0, 0]
    private(set) var turnTotal = 0
    private(set) var current = Player.one
    private(set) var lastRoll: Int? = nil
    private(set) var winner: Player? = nil

    init(target: Int = 50) {
        self.target = target
    }

    func score(of player: Player) -> Int {
        scores[player.rawValue]
    }

    // Roll the die. Pass in the value so tests can choose it.
    mutating func roll(_ value: Int = Int.random(in: 1...6)) -> PigEvent {
        guard winner == nil else { return .won(winner!) }
        lastRoll = value
        if value == 1 {
            turnTotal = 0
            current = current.other
            return .pigOut
        }
        turnTotal += value
        return .rolled(value)
    }

    // Bank the turn total and pass the die.
    mutating func hold() -> PigEvent {
        guard winner == nil else { return .won(winner!) }
        let banked = turnTotal
        scores[current.rawValue] += banked
        turnTotal = 0
        if scores[current.rawValue] >= target {
            winner = current
            return .won(current)
        }
        current = current.other
        return .held(banked)
    }
}

// Porkchop, the bot, holds at 20, or as soon as holding would win.
// Why 20? One more roll gains about 4 points five times in six,
// and loses the whole turn total one time in six.
// Those balance when the turn total is 20.
func botWantsToRoll(turnTotal: Int, score: Int, target: Int) -> Bool {
    if score + turnTotal >= target { return false }
    return turnTotal < 20
}
