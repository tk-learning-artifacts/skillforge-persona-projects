import SwiftUI

@main
struct PigOutApp: App {
    var body: some Scene {
        WindowGroup {
            TitleView()
        }
    }
}
