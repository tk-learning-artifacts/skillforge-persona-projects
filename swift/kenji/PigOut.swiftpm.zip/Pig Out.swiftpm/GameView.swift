import SwiftUI

// Screen 2: the game.
struct GameView: View {
    let versusBot: Bool
    @State private var game: PigGame
    @State private var message: String
    @State private var spin = 0.0        // degrees the die has turned
    @State private var pigOuts = 0       // goes up by 1 on every pig out, to shake the die
    @State private var rolls = 0         // goes up by 1 on every roll, for the haptic tap
    @State private var botBusy = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    init(versusBot: Bool, target: Int) {
        self.versusBot = versusBot
        _game = State(initialValue: PigGame(target: target))
        _message = State(initialValue: versusBot ? "Your turn. Roll the die." : "Player 1's turn. Roll the die.")
    }

    var body: some View {
        VStack(spacing: 20) {
            HStack(spacing: 12) {
                ScoreCard(name: name(.one), score: game.score(of: .one),
                          target: game.target, active: game.current == .one)
                ScoreCard(name: name(.two), score: game.score(of: .two),
                          target: game.target, active: game.current == .two)
            }

            DieView(value: game.lastRoll ?? 6, size: 140)
                .rotationEffect(.degrees(spin))
                .modifier(Shake(times: pigOuts))
                .opacity(game.lastRoll == nil ? 0.35 : 1)

            Text("Turn: \(game.turnTotal)")
                .font(.system(.largeTitle, design: .rounded, weight: .heavy))
                .contentTransition(.numericText(value: Double(game.turnTotal)))

            // Every event is said in words, not only by sound or motion.
            Text(message)
                .font(.title3)
                .multilineTextAlignment(.center)
                .frame(minHeight: 60)

            if game.winner != nil {
                Button("Play again") {
                    game = PigGame(target: game.target)
                    message = "\(turnOf(.one)) Roll the die."
                }
                .buttonStyle(.borderedProminent)
                .font(.title2.weight(.bold))
            } else {
                HStack(spacing: 16) {
                    Button { roll() } label: {
                        Label("Roll", systemImage: "die.face.5")
                            .frame(maxWidth: .infinity, minHeight: 56)
                    }
                    .buttonStyle(.borderedProminent)

                    Button { hold() } label: {
                        Label("Hold", systemImage: "tray.and.arrow.down")
                            .frame(maxWidth: .infinity, minHeight: 56)
                    }
                    .buttonStyle(.bordered)
                    .disabled(game.turnTotal == 0)
                }
                .font(.title2.weight(.bold))
                .disabled(botsTurn || botBusy)
            }
            Spacer()
        }
        .padding()
        .navigationTitle("First to \(game.target)")
        .navigationBarTitleDisplayMode(.inline)
        .sensoryFeedback(.impact, trigger: rolls)
        .sensoryFeedback(.error, trigger: pigOuts)
    }

    private var botsTurn: Bool { versusBot && game.current == .two }

    private func name(_ player: Player) -> String {
        if player == .one { return versusBot ? "You" : "Player 1" }
        return versusBot ? "Porkchop" : "Player 2"
    }

    // "Your turn." or "Porkchop's turn."
    private func turnOf(_ player: Player) -> String {
        name(player) == "You" ? "Your turn." : "\(name(player))'s turn."
    }

    private func roll() {
        let player = game.current
        report(game.roll(), by: player)
        if botsTurn { playBot() }
    }

    private func hold() {
        let player = game.current
        report(game.hold(), by: player)
        if botsTurn { playBot() }
    }

    // Turn an event into words, motion, a haptic and a VoiceOver announcement.
    private func report(_ event: PigEvent, by player: Player) {
        let who = name(player)
        switch event {
        case .rolled(let value):
            rolls += 1
            animate(.easeOut(duration: 0.35)) { spin += 360 }
            message = "\(who) rolled \(value). Turn total \(game.turnTotal)."
        case .pigOut:
            rolls += 1
            animate(.linear(duration: 0.4)) { pigOuts += 1 }
            message = "Pig out! \(who) rolled a 1 and lost the turn. \(turnOf(game.current))"
        case .held(let banked):
            message = "\(who) banked \(banked). \(turnOf(game.current))"
        case .won(let winner):
            let verb = name(winner) == "You" ? "win" : "wins"
            message = "\(name(winner)) \(verb), \(game.score(of: winner)) to \(game.score(of: winner.other))!"
        }
        AccessibilityNotification.Announcement(message).post()
    }

    // With Reduce Motion on, change the value with no animation.
    private func animate(_ animation: Animation, _ change: () -> Void) {
        if reduceMotion {
            change()
        } else {
            withAnimation(animation, change)
        }
    }

    // Porkchop plays slowly, so you can watch every roll.
    private func playBot() {
        guard !botBusy else { return }
        botBusy = true
        Task {
            while botsTurn && game.winner == nil {
                try? await Task.sleep(for: .seconds(1.2))
                let wantsToRoll = botWantsToRoll(turnTotal: game.turnTotal,
                                                 score: game.score(of: .two),
                                                 target: game.target)
                report(wantsToRoll ? game.roll() : game.hold(), by: .two)
            }
            botBusy = false
        }
    }
}

// One player's score, with a bar that fills towards the target.
struct ScoreCard: View {
    let name: String
    let score: Int
    let target: Int
    let active: Bool

    var body: some View {
        VStack(spacing: 6) {
            Text(active ? "▶ \(name)" : name)
                .font(.headline)
            Text("\(score)")
                .font(.system(.largeTitle, design: .rounded, weight: .bold))
                .contentTransition(.numericText(value: Double(score)))
            ProgressView(value: Double(min(score, target)), total: Double(target))
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(active ? Color.pigPink.opacity(0.15) : Color.gray.opacity(0.1),
                    in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16)
            .stroke(active ? Color.pigPink : .clear, lineWidth: 3))
        // The arrow and the outline show whose turn it is, so colour is not the only clue.
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(name), \(score) of \(target)\(active ? ", playing now" : "")")
    }
}

// Shakes a view side to side, three times, whenever `times` goes up by 1.
struct Shake: GeometryEffect {
    var animatableData: CGFloat

    init(times: Int) {
        animatableData = CGFloat(times)
    }

    func effectValue(size: CGSize) -> ProjectionTransform {
        ProjectionTransform(CGAffineTransform(translationX: 12 * sin(animatableData * .pi * 6), y: 0))
    }
}

#Preview {
    NavigationStack {
        GameView(versusBot: true, target: 50)
    }
}
