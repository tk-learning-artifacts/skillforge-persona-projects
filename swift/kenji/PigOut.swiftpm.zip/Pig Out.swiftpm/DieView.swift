import SwiftUI

// A die face drawn with circles, so it needs no images.
struct DieView: View {
    let value: Int
    var size: CGFloat = 120

    // Where the pips go on a 3 by 3 grid, counted 0 to 8.
    private var pips: [Int] {
        switch value {
        case 1: [4]
        case 2: [0, 8]
        case 3: [0, 4, 8]
        case 4: [0, 2, 6, 8]
        case 5: [0, 2, 4, 6, 8]
        default: [0, 2, 3, 5, 6, 8]
        }
    }

    var body: some View {
        let pip = size / 6
        RoundedRectangle(cornerRadius: size / 5)
            .fill(.white)
            .stroke(Color.black.opacity(0.8), lineWidth: 3)
            .frame(width: size, height: size)
            .overlay {
                Grid(horizontalSpacing: pip / 2, verticalSpacing: pip / 2) {
                    ForEach(0..<3, id: \.self) { row in
                        GridRow {
                            ForEach(0..<3, id: \.self) { col in
                                Circle()
                                    .fill(value == 1 ? Color.pigPink : .black)
                                    .frame(width: pip, height: pip)
                                    .opacity(pips.contains(row * 3 + col) ? 1 : 0)
                            }
                        }
                    }
                }
            }
            .accessibilityElement()
            .accessibilityLabel("Die showing \(value)")
    }
}

#Preview {
    HStack { ForEach(1...6, id: \.self) { DieView(value: $0, size: 48) } }
}
