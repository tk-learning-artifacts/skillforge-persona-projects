import SwiftUI

// Screen 1: the title, the rules, and who you play against.
struct TitleView: View {
    @State private var versusBot = true
    @State private var target = 50

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    DieView(value: 5, size: 96)
                        .accessibilityHidden(true)
                    Text("Pig Out")
                        .font(.system(size: 56, weight: .black, design: .rounded))
                        .foregroundStyle(Color.pigPink)

                    VStack(alignment: .leading, spacing: 10) {
                        Text("How to play").font(.headline)
                        Label("Roll as often as you like. Each roll adds to your turn.", systemImage: "die.face.3")
                        Label("Roll a 1 and you lose the whole turn. Pig out!", systemImage: "exclamationmark.triangle")
                        Label("Hold to bank your turn and pass the die.", systemImage: "tray.and.arrow.down")
                        Label("First to \(target) wins.", systemImage: "flag.checkered")
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 20))

                    Picker("Play against", selection: $versusBot) {
                        Text("Porkchop the bot").tag(true)
                        Text("A friend").tag(false)
                    }
                    .pickerStyle(.segmented)

                    Stepper("First to \(target)", value: $target, in: 20...100, step: 10)

                    NavigationLink {
                        GameView(versusBot: versusBot, target: target)
                    } label: {
                        Text("Play")
                            .font(.title2.weight(.bold))
                            .frame(maxWidth: .infinity, minHeight: 56)
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding()
            }
            .navigationTitle("Pig Out")
            .toolbar(.hidden, for: .navigationBar)
        }
        // Every button, bar and back arrow in the app uses the same pink.
        .tint(Color.pigPink)
    }
}

extension Color {
    // White text on this pink has a contrast of about 5.6 to 1.
    static let pigPink = Color(red: 0.75, green: 0.16, blue: 0.40)
}

#Preview {
    TitleView()
}
