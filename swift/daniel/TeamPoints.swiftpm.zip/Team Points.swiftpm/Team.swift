import SwiftUI

// One team in my class quiz.
// Each team has a colour AND a shape, so colour is never the only clue.
struct Team: Identifiable {
    let id = UUID()
    var name: String
    var symbol: String   // an SF Symbol name, like "star.fill"
    var color: Color
    var points = 0
}

extension Team {
    // The four teams I start every lesson with.
    // The colours are dark enough for white text on top.
    static let starters: [Team] = [
        Team(name: "Kopi", symbol: "circle.fill",
             color: Color(red: 0.43, green: 0.27, blue: 0.16)),
        Team(name: "Teh", symbol: "triangle.fill",
             color: Color(red: 0.69, green: 0.29, blue: 0.0)),
        Team(name: "Milo", symbol: "square.fill",
             color: Color(red: 0.11, green: 0.42, blue: 0.20)),
        Team(name: "Bandung", symbol: "star.fill",
             color: Color(red: 0.69, green: 0.15, blue: 0.40))
    ]
}
