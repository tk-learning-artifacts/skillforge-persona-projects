import SwiftUI

// Where the app starts. It shows the list of teams first.
@main
struct TeamPointsApp: App {
    var body: some Scene {
        WindowGroup {
            TeamsView()
        }
    }
}
