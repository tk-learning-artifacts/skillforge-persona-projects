import SwiftUI

// Screen 2: one team's score, with buttons to change it.
// @Binding means this screen changes the team that lives in TeamsView.
struct TeamView: View {
    @Binding var team: Team
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var bump = false

    var body: some View {
        VStack(spacing: 28) {
            Image(systemName: team.symbol)
                .font(.system(size: 56))
                .foregroundStyle(team.color)
                .accessibilityHidden(true)

            // The big score. It rolls to the new number and pops a little.
            Text("\(team.points)")
                .font(.system(size: 120, weight: .heavy, design: .rounded))
                .monospacedDigit()
                .contentTransition(.numericText(value: Double(team.points)))
                .scaleEffect(bump ? 1.15 : 1)
                .accessibilityLabel("\(team.points) points")

            HStack(spacing: 16) {
                PointButton(label: "−1", color: .gray) { change(by: -1) }
                    .accessibilityLabel("Take away 1 point")
                    .disabled(team.points == 0)
                PointButton(label: "+1", color: team.color) { change(by: 1) }
                    .accessibilityLabel("Add 1 point")
                PointButton(label: "+3", color: team.color) { change(by: 3) }
                    .accessibilityLabel("Add 3 points")
            }

            // Renaming here renames the team on screen 1 too, because of @Binding.
            TextField("Team name", text: $team.name)
                .textFieldStyle(.roundedBorder)
                .font(.title3)
                .multilineTextAlignment(.center)
                .frame(maxWidth: 280)
                .accessibilityLabel("Team name")

            Spacer()
        }
        .padding(.top, 32)
        .padding(.horizontal)
        .navigationTitle(team.name)
        .navigationBarTitleDisplayMode(.inline)
    }

    func change(by amount: Int) {
        let newPoints = max(0, team.points + amount)
        if reduceMotion {
            // No rolling numbers or popping for people who turned on Reduce Motion.
            team.points = newPoints
            return
        }
        withAnimation(.spring(duration: 0.3)) {
            team.points = newPoints
            bump = true
        }
        withAnimation(.spring(duration: 0.3).delay(0.15)) {
            bump = false
        }
    }
}

// A big round-cornered button. 80 by 64 points, well over Apple's 44 by 44.
struct PointButton: View {
    let label: String
    let color: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(label)
                .font(.system(.title, design: .rounded, weight: .bold))
                .frame(width: 80, height: 64)
                .foregroundStyle(.white)
                .background(color, in: RoundedRectangle(cornerRadius: 16))
        }
    }
}

#Preview {
    NavigationStack {
        TeamView(team: .constant(Team.starters[0]))
    }
}
