import SwiftUI

// Screen 1: every team and its score.
// The scores live HERE, in one @State array.
// Screen 2 gets a @Binding to one team, so its changes come back here.
struct TeamsView: View {
    @State private var teams = Team.starters
    @State private var askingToReset = false

    var body: some View {
        NavigationStack {
            List {
                Section {
                    // $teams gives me a binding to each team.
                    ForEach($teams) { $team in
                        NavigationLink {
                            TeamView(team: $team)
                        } label: {
                            TeamRow(team: team, isLeading: isLeading(team))
                        }
                    }
                } footer: {
                    Text("Tap a team to give points.")
                }
            }
            .navigationTitle("Team Points")
            .toolbar {
                Button("Reset") {
                    askingToReset = true
                }
                .disabled(teams.allSatisfy { $0.points == 0 })
            }
            .confirmationDialog("Set every score back to 0?",
                                isPresented: $askingToReset,
                                titleVisibility: .visible) {
                Button("Reset all scores", role: .destructive) {
                    for index in teams.indices {
                        teams[index].points = 0
                    }
                }
            }
        }
        // Toolbar text and the back button: black in light mode, white in dark mode.
        // Orange was hard to read on white.
        .tint(.primary)
    }

    // A team leads if it has the top score and that score is above 0.
    func isLeading(_ team: Team) -> Bool {
        let top = teams.map(\.points).max() ?? 0
        return top > 0 && team.points == top
    }
}

// One row in the list: shape, name, a crown for the leader, and the score.
struct TeamRow: View {
    let team: Team
    let isLeading: Bool

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: team.symbol)
                .font(.title2)
                .foregroundStyle(team.color)
                .frame(width: 32)
            Text(team.name)
                .font(.title3.weight(.semibold))
            if isLeading {
                Image(systemName: "crown.fill")
                    .foregroundStyle(.orange)
            }
            Spacer()
            Text("\(team.points)")
                .font(.system(.title, design: .rounded, weight: .bold))
                .monospacedDigit()
        }
        .padding(.vertical, 6)
        // VoiceOver reads the whole row as one sentence.
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(team.name), \(team.points) points\(isLeading ? ", in the lead" : "")")
    }
}

#Preview {
    TeamsView()
}
