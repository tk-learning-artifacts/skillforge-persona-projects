# Makes trial.db from schema.sql and puts in made-up data.
# Run it in a Bash console:  python3 setup_db.py
# Careful: running it again wipes everything.
import getpass
import os
import secrets
import sqlite3

from werkzeug.security import generate_password_hash

folder = os.path.dirname(os.path.abspath(__file__))
con = sqlite3.connect(os.path.join(folder, "trial.db"))

with open(os.path.join(folder, "schema.sql")) as f:
    con.executescript(f.read())

slots = [
    ("Robotics", "Wed 2:30 pm", 6),
    ("Robotics", "Fri 2:30 pm", 6),
    ("Infocomm", "Wed 2:30 pm", 8),
    ("Media Club", "Thu 3:00 pm", 5),
]
con.executemany("INSERT INTO slots (cca, time_label, places) VALUES (?, ?, ?)", slots)

# Made-up students. Never put real names in here.
fake_students = [
    (1, "Ali", "1E1"),
    (1, "Bee Lin", "1E3"),
    (3, "Chandra", "1E2"),
    (4, "Dev", "1E4"),
]
con.executemany(
    "INSERT INTO signups (slot_id, first_name, form_class) VALUES (?, ?, ?)",
    fake_students,
)

# The password is typed in, not written in this file.
username = input("Teacher username: ").strip().lower()
password = getpass.getpass("Teacher password (8 or more characters): ")
if len(password) < 8:
    raise SystemExit("Too short. Run me again.")
con.execute(
    "INSERT INTO teachers (username, pw_hash) VALUES (?, ?)",
    (username, generate_password_hash(password)),
)

con.commit()  # I forgot this line once. Nothing saved.
con.close()

with open(os.path.join(folder, "secret.key"), "w") as f:
    f.write(secrets.token_hex())

print("Done. Made trial.db and secret.key.")
