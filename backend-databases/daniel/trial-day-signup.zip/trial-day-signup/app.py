# Trial Day sign-up: Sec 1 students pick a CCA trial session.
# One page, made by Flask from templates/index.html.
import os
import re
import sqlite3

from flask import Flask, flash, redirect, render_template, request, session
from werkzeug.security import check_password_hash

folder = os.path.dirname(os.path.abspath(__file__))
DB_FILE = os.path.join(folder, "trial.db")

app = Flask(__name__)
with open(os.path.join(folder, "secret.key")) as f:
    app.secret_key = f.read().strip()


def get_db():
    con = sqlite3.connect(DB_FILE)
    con.row_factory = sqlite3.Row
    return con


@app.get("/")
def home():
    con = get_db()
    # LEFT JOIN, so a slot with no sign-ups still shows up, with 0 taken.
    slots = con.execute(
        "SELECT slots.id, slots.cca, slots.time_label, slots.places, "
        "COUNT(signups.id) AS taken "
        "FROM slots LEFT JOIN signups ON signups.slot_id = slots.id "
        "GROUP BY slots.id ORDER BY slots.cca, slots.id"
    ).fetchall()
    signups = []
    if "teacher" in session:
        signups = con.execute(
            "SELECT signups.id, signups.first_name, signups.form_class, "
            "slots.cca, slots.time_label "
            "FROM signups JOIN slots ON slots.id = signups.slot_id "
            "ORDER BY slots.cca, slots.id, signups.form_class"
        ).fetchall()
    con.close()
    return render_template("index.html", slots=slots, signups=signups)


@app.post("/signup")
def signup():
    first_name = request.form.get("first_name", "").strip()
    form_class = request.form.get("form_class", "").strip().upper()
    slot_id = request.form.get("slot_id", "")
    if not 1 <= len(first_name) <= 30:
        flash("Type a first name, 30 letters at most.")
        return redirect("/")
    if not re.fullmatch(r"[1-5][A-Z]{0,2}[0-9]{1,2}", form_class):
        flash("Type your class like 1E2.")
        return redirect("/")

    con = get_db()
    slot = con.execute(
        "SELECT slots.cca, slots.time_label, slots.places, COUNT(signups.id) AS taken "
        "FROM slots LEFT JOIN signups ON signups.slot_id = slots.id "
        "WHERE slots.id = ? GROUP BY slots.id",
        (slot_id,),
    ).fetchone()
    if slot is None:
        flash("Pick a session.")
    elif slot["taken"] >= slot["places"]:
        flash(f"Sorry, {slot['cca']} on {slot['time_label']} is full.")
    else:
        con.execute(
            "INSERT INTO signups (slot_id, first_name, form_class) VALUES (?, ?, ?)",
            (slot_id, first_name, form_class),
        )
        con.commit()
        flash(f"Done! See you at {slot['cca']}, {slot['time_label']}.")
    con.close()
    return redirect("/")  # back to the page, so a refresh won't sign up twice


@app.post("/login")
def login():
    username = request.form.get("username", "").strip().lower()
    password = request.form.get("password", "")
    con = get_db()
    teacher = con.execute(
        "SELECT username, pw_hash FROM teachers WHERE username = ?", (username,)
    ).fetchone()
    con.close()
    if teacher and check_password_hash(teacher["pw_hash"], password):
        session["teacher"] = teacher["username"]
        flash("Logged in. The sign-up list is at the bottom.")
    else:
        flash("Wrong username or password.")
    return redirect("/")


@app.post("/logout")
def logout():
    session.clear()
    flash("Logged out.")
    return redirect("/")


@app.post("/remove/<int:signup_id>")
def remove(signup_id):
    if "teacher" not in session:
        return "Teachers only.", 403
    con = get_db()
    con.execute("DELETE FROM signups WHERE id = ?", (signup_id,))
    con.commit()
    con.close()
    flash("Removed.")
    return redirect("/")
