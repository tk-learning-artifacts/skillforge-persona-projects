-- Trial Day sign-up tables. setup_db.py runs this file.
DROP TABLE IF EXISTS signups;
DROP TABLE IF EXISTS slots;
DROP TABLE IF EXISTS teachers;

-- One row for each trial session a CCA runs.
CREATE TABLE slots (
  id INTEGER PRIMARY KEY,
  cca TEXT NOT NULL,
  time_label TEXT NOT NULL,
  places INTEGER NOT NULL
);

-- One row for each student who signs up.
-- I took out phone number and parent email. The teacher meets them at the session anyway.
CREATE TABLE signups (
  id INTEGER PRIMARY KEY,
  slot_id INTEGER NOT NULL REFERENCES slots(id),
  first_name TEXT NOT NULL,
  form_class TEXT NOT NULL
);

-- Only teachers have logins. Students sign up without one.
CREATE TABLE teachers (
  id INTEGER PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  pw_hash TEXT NOT NULL
);
