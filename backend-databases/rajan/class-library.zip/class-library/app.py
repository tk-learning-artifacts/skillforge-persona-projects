"""Class library: a small Flask API on SQLite, with logins.

Every query uses ? placeholders. Passwords are stored as werkzeug hashes.
"""
import os
import re
import sqlite3

from flask import Flask, g, request, session
from werkzeug.security import check_password_hash, generate_password_hash

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "library.db")

# SQLite's 'now' is UTC. Singapore is UTC+8, so shift it, or books
# go overdue at 8 a.m. instead of midnight. This is our own fixed text,
# never user input, so it is safe to put into the SQL with an f-string.
TODAY = "date('now', '+8 hours')"

app = Flask(__name__, static_folder="static", static_url_path="")
with open(os.path.join(HERE, "secret.key")) as f:
    app.secret_key = f.read().strip()


def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(error):
    con = g.pop("db", None)
    if con is not None:
        con.close()


def rows(sql, params=()):
    return [dict(r) for r in db().execute(sql, params).fetchall()]


def me():
    """The logged-in user, or None."""
    if "user_id" not in session:
        return None
    return db().execute(
        "SELECT id, username, is_librarian FROM users WHERE id = ?",
        (session["user_id"],),
    ).fetchone()


def error(message, status):
    return {"error": message}, status


@app.get("/")
def home():
    return app.send_static_file("index.html")


# ---- Accounts ----

@app.post("/api/signup")
def signup():
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip().lower()
    password = str(data.get("password", ""))
    if not re.fullmatch(r"[a-z0-9_]{3,20}", username):
        return error("Use 3 to 20 letters, numbers or _.", 400)
    if len(password) < 8:
        return error("Use at least 8 characters.", 400)
    try:
        with db():
            cur = db().execute(
                "INSERT INTO users (username, pw_hash) VALUES (?, ?)",
                (username, generate_password_hash(password)),
            )
    except sqlite3.IntegrityError:
        return error("That username is taken.", 409)
    session["user_id"] = cur.lastrowid
    return {"username": username, "is_librarian": 0}, 201


@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip().lower()
    password = str(data.get("password", ""))
    user = db().execute(
        "SELECT id, username, pw_hash, is_librarian FROM users WHERE username = ?",
        (username,),
    ).fetchone()
    # Same message either way, so nobody learns which usernames exist.
    if user is None or not check_password_hash(user["pw_hash"], password):
        return error("Wrong username or password.", 401)
    session["user_id"] = user["id"]
    return {"username": user["username"], "is_librarian": user["is_librarian"]}


@app.post("/api/logout")
def logout():
    session.clear()
    return {"ok": True}


@app.get("/api/me")
def whoami():
    user = me()
    if user is None:
        return error("Not logged in.", 401)
    return {"username": user["username"], "is_librarian": user["is_librarian"]}


# ---- Books ----

@app.get("/api/books")
def list_books():
    return rows(
        "SELECT b.id, b.title, b.author, l.id IS NOT NULL AS on_loan "
        "FROM books b LEFT JOIN loans l "
        "ON l.book_id = b.id AND l.returned_on IS NULL "
        "ORDER BY b.title"
    )


@app.get("/api/books/<int:book_id>")
def one_book(book_id):
    found = rows("SELECT id, title, author FROM books WHERE id = ?", (book_id,))
    if not found:
        return error("No book with that id.", 404)
    return found[0]


@app.post("/api/books")
def add_book():
    user = me()
    if user is None or not user["is_librarian"]:
        return error("Only the librarian can add books.", 403)
    data = request.get_json(silent=True) or {}
    title = str(data.get("title", "")).strip()
    author = str(data.get("author", "")).strip()
    if not (1 <= len(title) <= 100 and 1 <= len(author) <= 100):
        return error("Give a title and an author, 100 characters at most.", 400)
    with db():
        cur = db().execute(
            "INSERT INTO books (title, author) VALUES (?, ?)", (title, author)
        )
    return {"id": cur.lastrowid, "title": title, "author": author}, 201


# ---- Loans ----

@app.get("/api/loans")
def my_loans():
    user = me()
    if user is None:
        return error("Log in first.", 401)
    return rows(
        "SELECT l.id, b.title, l.due_date, "
        f"l.due_date < {TODAY} AS overdue "
        "FROM loans l JOIN books b ON b.id = l.book_id "
        "WHERE l.user_id = ? AND l.returned_on IS NULL "
        "ORDER BY l.due_date",
        (user["id"],),
    )


@app.post("/api/loans")
def borrow():
    user = me()
    if user is None:
        return error("Log in first.", 401)
    data = request.get_json(silent=True) or {}
    book_id = data.get("book_id")
    if not isinstance(book_id, int):
        return error("Send a book_id number.", 400)
    if not rows("SELECT id FROM books WHERE id = ?", (book_id,)):
        return error("No book with that id.", 404)
    try:
        with db():
            cur = db().execute(
                "INSERT INTO loans (user_id, book_id, due_date) "
                f"VALUES (?, ?, date({TODAY}, '+14 days'))",
                (user["id"], book_id),
            )
    except sqlite3.IntegrityError:
        return error("Someone already has that book.", 409)
    return rows("SELECT id, due_date FROM loans WHERE id = ?", (cur.lastrowid,))[0], 201


@app.post("/api/loans/<int:loan_id>/return")
def give_back(loan_id):
    user = me()
    if user is None:
        return error("Log in first.", 401)
    with db():
        cur = db().execute(
            f"UPDATE loans SET returned_on = {TODAY} "
            "WHERE id = ? AND returned_on IS NULL AND (user_id = ? OR ? = 1)",
            (loan_id, user["id"], user["is_librarian"]),
        )
    if cur.rowcount == 0:
        return error("No open loan of yours with that id.", 404)
    return {"ok": True}


@app.get("/api/overdue")
def overdue():
    user = me()
    if user is None or not user["is_librarian"]:
        return error("Only the librarian can see this.", 403)
    return rows(
        "SELECT l.id, u.username, b.title, l.due_date "
        "FROM loans l "
        "JOIN users u ON u.id = l.user_id "
        "JOIN books b ON b.id = l.book_id "
        f"WHERE l.returned_on IS NULL AND l.due_date < {TODAY} "
        "ORDER BY l.due_date"
    )


if __name__ == "__main__":
    app.run(debug=True)
