-- Tables for the class library. Run by setup_db.py.
DROP TABLE IF EXISTS loans;
DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INTEGER PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,      -- a made-up handle, never a real name
  pw_hash TEXT NOT NULL,              -- werkzeug hash, never the password
  is_librarian INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE books (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  author TEXT NOT NULL
);

CREATE TABLE loans (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  book_id INTEGER NOT NULL REFERENCES books(id),
  due_date TEXT NOT NULL,             -- YYYY-MM-DD, so text order is date order
  returned_on TEXT                    -- NULL while the book is out
);

-- A book can be out on only one loan at a time.
-- The database enforces it, so two clicks at once can't both win.
CREATE UNIQUE INDEX one_open_loan ON loans(book_id) WHERE returned_on IS NULL;
