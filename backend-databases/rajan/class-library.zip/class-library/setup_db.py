"""Build library.db from schema.sql and fill it with made-up data.

Run it once from a Bash console:  python3 setup_db.py
Running it again wipes the database and starts over.
"""
import getpass
import os
import secrets
import sqlite3
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from werkzeug.security import generate_password_hash

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "library.db")
KEY = os.path.join(HERE, "secret.key")

BOOKS = [
    ("Animal Farm", "George Orwell"),
    ("The Hobbit", "J. R. R. Tolkien"),
    ("Holes", "Louis Sachar"),
    ("The Giver", "Lois Lowry"),
    ("Wonder", "R. J. Palacio"),
    ("Frankenstein", "Mary Shelley"),
]

# Made-up readers. Their passwords are random and printed nowhere,
# so nobody can log in as them. They only exist to own sample loans.
READERS = ["reader_kite", "reader_moss", "reader_pebble"]


def sg_today():
    return datetime.now(ZoneInfo("Asia/Singapore")).date()


def main():
    password = getpass.getpass("Choose a password for the librarian account: ")
    if len(password) < 8:
        raise SystemExit("Use at least 8 characters.")

    con = sqlite3.connect(DB)
    with open(os.path.join(HERE, "schema.sql")) as f:
        con.executescript(f.read())

    with con:  # commits at the end of the block
        con.execute(
            "INSERT INTO users (username, pw_hash, is_librarian) VALUES (?, ?, 1)",
            ("librarian", generate_password_hash(password)),
        )
        for name in READERS:
            con.execute(
                "INSERT INTO users (username, pw_hash) VALUES (?, ?)",
                (name, generate_password_hash(secrets.token_urlsafe(16))),
            )
        con.executemany("INSERT INTO books (title, author) VALUES (?, ?)", BOOKS)

        today = sg_today()
        sample_loans = [  # (user_id, book_id, days from today)
            (2, 1, -5),   # overdue
            (3, 3, -1),   # overdue by a day
            (3, 4, 9),    # not due yet
        ]
        for user_id, book_id, days in sample_loans:
            due = (today + timedelta(days=days)).isoformat()
            con.execute(
                "INSERT INTO loans (user_id, book_id, due_date) VALUES (?, ?, ?)",
                (user_id, book_id, due),
            )
    con.close()

    # Flask signs its session cookie with this key. Keep it out of your code.
    with open(KEY, "w") as f:
        f.write(secrets.token_hex())
    print("Made library.db and secret.key. Log in as 'librarian'.")


if __name__ == "__main__":
    main()
