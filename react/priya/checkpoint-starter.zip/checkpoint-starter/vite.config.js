import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// base './' makes every path relative to the page. The same build then works
// in any repository name, so 30 students don't need 30 different settings.
export default defineConfig({
  base: './',
  plugins: [react()],
  // For GitHub Codespaces: listen on every address, and answer the
  // CODESPACENAME-5173.app.github.dev address that Codespaces gives the preview.
  server: { host: true, allowedHosts: ['.app.github.dev'] },
})
