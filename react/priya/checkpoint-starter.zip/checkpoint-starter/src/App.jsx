import { useEffect, useState } from 'react'
import SetPicker from './components/SetPicker.jsx'
import Progress from './components/Progress.jsx'
import QuestionCard from './components/QuestionCard.jsx'
import Results from './components/Results.jsx'
import './App.css'

// The three question sets. Each one is a file in public/questions/.
const SETS = [
  { id: 'html', name: 'HTML' },
  { id: 'css', name: 'CSS' },
  { id: 'js', name: 'JavaScript' },
]

export default function App() {
  // State: only what the app must remember between clicks.
  const [setId, setSetId] = useState('html')
  const [quiz, setQuiz] = useState(null)
  const [error, setError] = useState(null)
  const [tries, setTries] = useState(0)
  const [index, setIndex] = useState(0)
  const [answers, setAnswers] = useState([])

  // Effect: load the chosen set. The ignore flag throws away a late answer
  // if the student picks another set before this one arrives.
  useEffect(() => {
    let ignore = false
    // TODO 1 (fill the gap): load the set the student picked, not the demo.
    // Build the path from setId. Don't put a slash at the start.
    const path = 'questions/demo.json'
    fetch(path)
      .then((response) => {
        if (!response.ok) throw new Error(`The file ${path} did not load (status ${response.status}).`)
        return response.json()
      })
      .then((data) => {
        if (!ignore) setQuiz(data)
      })
      .catch((err) => {
        if (!ignore) setError(err.message)
      })
    return () => {
      ignore = true
    }
  }, [setId, tries])

  function startOver() {
    setIndex(0)
    setAnswers([])
  }

  function pickSet(id) {
    if (id === setId) return
    setSetId(id)
    setQuiz(null)
    setError(null)
    startOver()
  }

  function tryAgain() {
    setError(null)
    setTries(tries + 1)
  }

  function pickChoice(choiceId) {
    const question = quiz.questions[index]
    // TODO 2 (finish the idea): work out if the pick is right.
    // Compare choiceId with question.answer, so the score goes up.
    const correct = false
    setAnswers([...answers, { questionId: question.id, choiceId, correct }])
  }

  // Worked out from state on every draw, so it is never stored.
  const score = answers.filter((a) => a.correct).length
  const finished = quiz !== null && index === quiz.questions.length
  const question = quiz && !finished ? quiz.questions[index] : null
  const picked = question ? answers.find((a) => a.questionId === question.id) : null

  return (
    <div className="app">
      <header className="top">
        <p className="eyebrow">Checkpoint</p>
        <h1>Am I ready for React?</h1>
        <p className="lede">Pick a set. Answer 5 questions. See which outcomes to revisit.</p>
        <SetPicker sets={SETS} current={setId} onPick={pickSet} />
      </header>

      <main className="stage">
        {error && (
          <div className="panel error" role="alert">
            <p>{error}</p>
            <button type="button" className="btn" onClick={tryAgain}>Try again</button>
          </div>
        )}

        {!error && quiz === null && <p className="panel loading" role="status">Loading questions...</p>}

        {question && (
          <>
            <Progress questions={quiz.questions} answers={answers} index={index} />
            <QuestionCard
              key={question.id}
              question={question}
              number={index + 1}
              total={quiz.questions.length}
              outcome={quiz.outcomes.find((o) => o.id === question.outcome)}
              picked={picked ? picked.choiceId : null}
              onPick={pickChoice}
            />
            {picked && (
              <button type="button" className="btn primary next" onClick={() => setIndex(index + 1)}>
                {index + 1 === quiz.questions.length ? 'See my results' : 'Next question'}
              </button>
            )}
            <p className="score" aria-live="polite">{answers.length > 0 && `Score so far: ${score} of ${answers.length}`}</p>
          </>
        )}

        {finished && <Results quiz={quiz} answers={answers} score={score} onRestart={startOver} />}
      </main>
    </div>
  )
}
