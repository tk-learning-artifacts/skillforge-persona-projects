import { useEffect, useRef } from 'react'
import ChoiceButton from './ChoiceButton.jsx'

export default function QuestionCard({ question, number, total, outcome, picked, onPick }) {
  const heading = useRef(null)

  // After "Next question", move keyboard focus to the new question.
  useEffect(() => {
    if (number > 1) heading.current.focus()
  }, [number])

  const answered = picked !== null
  const right = picked === question.answer

  return (
    <section className="card" aria-labelledby={`q-${question.id}`}>
      <p className="meta">
        Question {number} of {total} <span className="tag">{outcome.id}</span>
      </p>
      <h2 id={`q-${question.id}`} ref={heading} tabIndex={-1}>{question.prompt}</h2>
      {question.code && <pre className="code"><code>{question.code}</code></pre>}

      <ul className="choices">
        {question.choices.map((choice, i) => {
          let state = 'open'
          if (answered && choice.id === question.answer) state = 'right'
          else if (answered && choice.id === picked) state = 'wrong'
          return (
            <ChoiceButton
              key={choice.id}
              choice={choice}
              letter={'ABCD'[i]}
              state={state}
              disabled={answered}
              onPick={onPick}
            />
          )
        })}
      </ul>

      <div aria-live="polite">
        {answered && (
          <div className={`feedback ${right ? 'good' : 'bad'}`}>
            <p className="verdict">{right ? 'Right.' : 'Not this time.'}</p>
            <p>{question.explain}</p>
            <p className="small">
              Outcome {outcome.id}: {outcome.text}. <a href={question.source} target="_blank" rel="noreferrer">Read more on MDN</a>
            </p>
          </div>
        )}
      </div>
    </section>
  )
}
