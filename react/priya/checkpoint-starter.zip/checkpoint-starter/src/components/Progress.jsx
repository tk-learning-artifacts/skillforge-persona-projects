// One dot per question: done right, done wrong, now, or still to come.
export default function Progress({ questions, answers, index }) {
  return (
    <ol className="progress" aria-label={`Question ${index + 1} of ${questions.length}`}>
      {questions.map((q, i) => {
        const answer = answers.find((a) => a.questionId === q.id)
        let state = 'todo'
        if (answer) state = answer.correct ? 'right' : 'wrong'
        else if (i === index) state = 'now'
        return (
          <li key={q.id} className={`dot ${state}`}>
            <span className="sr-only">{`Question ${i + 1}: ${state}`}</span>
          </li>
        )
      })}
    </ol>
  )
}
