// Props: the list of sets, the one in use, and what to do on a tap.
export default function SetPicker({ sets, current, onPick }) {
  return (
    <div className="picker" role="group" aria-label="Question set">
      {sets.map((set) => (
        <button
          key={set.id}
          type="button"
          className="chip"
          aria-pressed={set.id === current}
          onClick={() => onPick(set.id)}
        >
          {set.name}
        </button>
      ))}
    </div>
  )
}
