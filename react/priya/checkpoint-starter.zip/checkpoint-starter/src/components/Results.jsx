// The end screen: the score and an exit line.
export default function Results({ quiz, answers, score, onRestart }) {
  const total = quiz.questions.length
  const exitLine = `${quiz.title}: ${score}/${total}.`

  // TODO 3 (stretch: make it new): list each outcome in quiz.outcomes as Met
  // or Revisit. An outcome is met when every question with that outcome was
  // right. Use map, and give each item a key. Then add the outcomes to revisit
  // to the exit line.

  return (
    <section className="card results" aria-labelledby="results-title">
      <h2 id="results-title">You scored {score} of {total}</h2>
      <p className="small">Copy this line into your class exit form:</p>
      <p className="exit">{exitLine}</p>
      <button type="button" className="btn primary" onClick={onRestart}>Do this set again</button>
    </section>
  )
}
