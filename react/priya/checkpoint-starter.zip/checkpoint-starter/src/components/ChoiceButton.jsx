// A single answer. It shows a tick or a cross once the student has picked.
export default function ChoiceButton({ choice, letter, state, disabled, onPick }) {
  const mark = { right: ' ✓', wrong: ' ✗' }[state] || ''
  return (
    <li>
      <button type="button" className={`choice ${state}`} disabled={disabled} onClick={() => onPick(choice.id)}>
        <span className="letter" aria-hidden="true">{letter}</span>
        <span className="text">{choice.text}</span>
        <span className="mark" aria-hidden="true">{mark}</span>
      </button>
    </li>
  )
}
