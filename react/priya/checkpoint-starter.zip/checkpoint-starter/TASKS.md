# Task card: finish the Checkpoint quiz

Goal: a quiz that loads the set you pick, keeps score, and tells you what to revisit.

## Step 0: predict, then run

Read `src/App.jsx`. Predict: what happens when you pick CSS? What score do you get for all right answers?
Then run `npm run dev` and open the preview. Were you right?

## Step 1: TODO 1, load the set you picked (src/App.jsx)

Change `path` so it uses `setId`. Test: pick CSS. The first question should be about a `.card` selector.

<details><summary>Hint</summary>Use a template string with backticks: `questions/${setId}.json`. No slash at the start, or it breaks on GitHub Pages.</details>

## Step 2: TODO 2, keep score (src/App.jsx)

Work out `correct` by comparing `choiceId` with `question.answer`. Test: one right and one wrong answer. The score should say 1 of 2.

<details><summary>Hint</summary>`===` gives true or false. That is exactly what `correct` needs.</details>

## Step 3: save your work

Source Control, type a message such as "Load sets and keep score", then Commit and Sync.

## Stretch: TODO 3, outcomes to revisit (src/components/Results.jsx)

Show each outcome as Met or Revisit. Use `map` with a `key`.

<details><summary>Hint</summary>For each outcome, find the questions with that outcome. It is met if every answer to them was right. `filter` and `every` help.</details>
