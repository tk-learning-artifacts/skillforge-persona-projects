// The end screen: the score, each outcome met or to revisit, and an exit line.
export default function Results({ quiz, answers, score, onRestart }) {
  const total = quiz.questions.length

  const outcomes = quiz.outcomes.map((outcome) => {
    const ids = quiz.questions.filter((q) => q.outcome === outcome.id).map((q) => q.id)
    const met = answers.filter((a) => ids.includes(a.questionId)).every((a) => a.correct)
    return { ...outcome, met }
  })
  const revisit = outcomes.filter((o) => !o.met).map((o) => o.id)
  const exitLine = `${quiz.title}: ${score}/${total}. Revisit: ${revisit.length ? revisit.join(', ') : 'none'}.`

  return (
    <section className="card results" aria-labelledby="results-title">
      <h2 id="results-title">You scored {score} of {total}</h2>
      <ul className="outcomes">
        {outcomes.map((o) => (
          <li key={o.id} className={o.met ? 'met' : 'revisit'}>
            <span className="tag">{o.id}</span>
            <span className="text">{o.text}</span>
            <strong>{o.met ? 'Met' : 'Revisit'}</strong>
          </li>
        ))}
      </ul>
      <p className="small">Copy this line into your class exit form:</p>
      <p className="exit">{exitLine}</p>
      <button type="button" className="btn primary" onClick={onRestart}>Do this set again</button>
    </section>
  )
}
