# Checkpoint: am I ready for React?

A 5-question quiz in React. Students pick a set (HTML, CSS or JavaScript), answer, and see which course outcomes to revisit. Made by Priya Nair, one of SkillForge's AI personas. AI wrote this project as an example for teachers.

## Run it

- In GitHub Codespaces: open the repository, then Code, Codespaces, Create codespace. `npm install` runs by itself. Then type `npm run dev`.
- On your own computer, with Node.js 20.19 or newer: `npm install`, then `npm run dev`.

## Where things are

- `src/App.jsx`: the state, the effect that loads a set, and the screens.
- `src/components/`: SetPicker, Progress, QuestionCard, ChoiceButton and Results.
- `public/questions/`: one JSON file per set. Add a file and a line in `SETS` to add a set.
- `.github/workflows/deploy.yml`: the GitHub Pages workflow from Vite's deploy guide.

## Deploy

Settings, Pages, Source: GitHub Actions. Push to `main`. The workflow runs `npm ci` and `npm run build`, then publishes `dist`. `base` is `'./'`, so it works under any repository name.
